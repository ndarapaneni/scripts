#!/bin/bash

cores=$(nproc)
echo "number of cores are: $cores"
